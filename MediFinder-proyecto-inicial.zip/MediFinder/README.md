# MediFinder (proyecto inicial Android)

Proyecto Android nativo con Kotlin y Jetpack Compose. Incluye:
- Interfaz inicial oscura y futurista.
- Pantalla de búsqueda y categorías.
- Solicitud de permisos de ubicación solo cuando el usuario pulsa el botón.
- Acceso como invitado; la autenticación real queda pendiente de conectar.
- Flujo de GitHub Actions para compilar un APK de depuración en la nube.

## Estado importante
Este es un **prototipo inicial**, no una aplicación médica completa ni lista para publicarse. La consulta de establecimientos en vivo, mapa interactivo, búsqueda manual por localidad, favoritos persistentes, autenticación y pruebas de seguridad deben implementarse y verificarse antes de considerarla funcional para uso público.

Los datos de OpenStreetMap pueden estar incompletos o desactualizados. No usar la aplicación como sustituto de servicios de emergencia. En México, ante una emergencia llama al 911.

## Compilar APK sin computadora
1. Sube todos los archivos de este proyecto a un repositorio de GitHub llamado `MediFinder`.
2. Abre la pestaña **Actions** del repositorio.
3. Selecciona **Build MediFinder APK** y pulsa **Run workflow** (o espera a que termine el flujo automático después de subir a `main`).
4. Abre la ejecución terminada, entra a **Artifacts** y descarga `MediFinder-debug-apk`.
5. Descomprime el ZIP y encontrarás `app-debug.apk`.

El APK de depuración sirve para pruebas. Para distribuir públicamente se necesita una compilación firmada de lanzamiento y revisión adicional.
