package com.medifinder.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder

private val Navy = Color(0xFF071525)
private val Panel = Color(0xFF10263D)
private val Cyan = Color(0xFF45C8F5)
private val Muted = Color(0xFF9DB3C8)

data class Place(
    val name: String,
    val type: String,
    val address: String,
    val lat: Double,
    val lon: Double,
    val phone: String = "",
    val opening: String = ""
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MediFinderApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MediFinderApp() {
    val context = LocalContext.current
    var location by remember { mutableStateOf<Location?>(null) }
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Todos") }
    var places by remember { mutableStateOf<List<Place>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Comparte tu ubicación para buscar servicios cercanos.") }
    var selected by remember { mutableStateOf<Place?>(null) }
    var guestMode by remember { mutableStateOf(false) }
    var showAccount by remember { mutableStateOf(false) }
    val categories = listOf("Todos", "Hospitales", "Farmacias", "Clínicas", "Consultorios", "Urgencias", "Laboratorios")

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result.values.any { it }) {
            location = getLastKnownLocation(context)
            if (location != null) message = "Ubicación obtenida. Puedes buscar servicios cercanos."
            else message = "No se pudo obtener la ubicación. Activa el GPS e inténtalo de nuevo."
        } else {
            message = "Permiso no concedido. Puedes buscar manualmente por localidad."
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyan, background = Navy, surface = Panel,
            onPrimary = Navy, onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Scaffold(containerColor = Navy, topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("MediFinder", fontWeight = FontWeight.Bold)
                        Text("ATENCIÓN MÉDICA CERCA DE TI", style = MaterialTheme.typography.labelSmall, color = Muted)
                    }
                },
                actions = {
                    IconButton(onClick = { showAccount = true }) {
                        Icon(Icons.Default.AccountCircle, contentDescription = "Cuenta", tint = Cyan)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy)
            )
        }) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 28.dp)
            ) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Encuentra atención médica", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Text("Hospitales, farmacias, clínicas y más en un solo lugar.", color = Muted)
                            Button(
                                onClick = {
                                    val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                                    val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                                    if (fine || coarse) {
                                        location = getLastKnownLocation(context)
                                        message = if (location != null) "Ubicación lista." else "No se encontró ubicación. Comprueba que el GPS esté activado."
                                    } else permissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.MyLocation, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text("Usar mi ubicación")
                            }
                        }
                    }
                }
                item {
                    OutlinedTextField(
                        value = query, onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Buscar por nombre o localidad") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Cyan, focusedLabelColor = Cyan,
                            unfocusedBorderColor = Muted, cursorColor = Cyan
                        )
                    )
                }
                item {
                    Text("Categorías", fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        listOf("Todos", "Hospitales", "Farmacias").forEach { item ->
                            FilterChip(selected = category == item, onClick = { category = item }, label = { Text(item) })
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        listOf("Clínicas", "Consultorios", "Urgencias", "Laboratorios").forEach { item ->
                            FilterChip(selected = category == item, onClick = { category = item }, label = { Text(item) })
                        }
                    }
                }
                item {
                    Button(
                        onClick = {
                            if (location == null) {
                                message = "Primero comparte tu ubicación o busca por localidad."
                            } else {
                                loading = true
                                message = "Buscando en OpenStreetMap…"
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Buscar servicios cercanos") }
                    Text(message, color = Muted, style = MaterialTheme.typography.bodySmall)
                }
                item { Text("Resultados", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge) }
                if (places.isEmpty()) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                            Text("Aquí aparecerán los establecimientos encontrados. La búsqueda en vivo y el mapa se conectarán en la siguiente etapa de configuración.", Modifier.padding(16.dp), color = Muted)
                        }
                    }
                } else {
                    items(places) { place ->
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable { selected = place },
                            colors = CardDefaults.cardColors(containerColor = Panel)
                        ) {
                            Column(Modifier.padding(14.dp)) {
                                Text(place.name, fontWeight = FontWeight.Bold)
                                Text(place.type, color = Cyan, style = MaterialTheme.typography.labelMedium)
                                Text(place.address, color = Muted, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }

        if (showAccount) {
            AlertDialog(
                onDismissRequest = { showAccount = false },
                title = { Text("Tu acceso") },
                text = { Text("Puedes utilizar MediFinder como invitado. El registro de cuenta será opcional y se habilitará al conectar un servicio seguro de autenticación.") },
                confirmButton = { TextButton(onClick = { guestMode = true; showAccount = false }) { Text("Continuar como invitado") } },
                dismissButton = { TextButton(onClick = { showAccount = false }) { Text("Cerrar") } },
                containerColor = Panel
            )
        }
    }
}

private fun getLastKnownLocation(context: Context): Location? {
    val manager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    return try {
        val providers = manager.getProviders(true)
        providers.mapNotNull { provider ->
            try { manager.getLastKnownLocation(provider) } catch (_: SecurityException) { null }
        }.maxByOrNull { it.time }
    } catch (_: Exception) { null }
}
